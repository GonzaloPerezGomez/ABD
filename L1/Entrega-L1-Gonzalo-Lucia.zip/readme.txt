GraphDB-Gonzalo: http://104.155.108.236:7200/
GraphDB-Lucia: http://35.195.178.0:7200/

Los grafos son iguales en ambos servidores

Named Graph:
    Archivo RDF 1: http://adb.L1.Archivo.RDF.1/
    Archivo RDF 2: http://adb.L1.Archivo.RDF.2/
    Archivo RDF 3: http://adb.L1.Archivo.RDF.3/
    Archivo RDF 4: http://adb.L1.Archivo.RDF.4/
